import { createIdentityRuntime } from "@bauth/identity-platform";

export const identityRuntime = createIdentityRuntime({
  apiBase: "http://localhost:5000",
accountCenterUrl: "http://localhost:3000/myaccount",
manageAccountUrl: "http://localhost:3000/myaccount",
addAccountUrl: "http://localhost:3000/myaccount?flow=add",
loginUrl: "http://localhost:3000/myaccount",
});

identityRuntime.subscribe(() => {
  const snapshot = identityRuntime.getSnapshot();
  window.dispatchEvent(
    new CustomEvent("bauth:identity", {
      detail: snapshot
    })
  );
});

void identityRuntime.hydrate();
