import { IdentityHeader, IdentityProvider } from "@bauth/identity-platform";

const identityConfig = {
  apiBase: "http://localhost:5000",
accountCenterUrl: "http://localhost:3000/myaccount",
manageAccountUrl: "http://localhost:3000/myaccount",
addAccountUrl: "http://localhost:3000/myaccount?flow=add",
loginUrl: "http://localhost:3000/myaccount",
};

export function AppShell() {
  return (
    <IdentityProvider config={identityConfig}>
      <IdentityHeader />
    </IdentityProvider>
  );
}
