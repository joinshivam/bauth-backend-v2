"use client";

import { IdentityPlatform } from "@bauth/identity-platform";

export function BAuthIdentityLayer() {
  return (
    <IdentityPlatform
      config={{
        apiBase: process.env.NEXT_PUBLIC_BAUTH_API_BASE ?? "",
        accountCenterUrl: process.env.NEXT_PUBLIC_BAUTH_ACCOUNT_CENTER ?? ""
      }}
    />
  );
}
