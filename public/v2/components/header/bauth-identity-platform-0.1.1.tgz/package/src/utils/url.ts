import type { IdentityRecoveryReason } from "../core/types";

export function joinUrl(base: string, path: string): string {
  if (/^https?:\/\//i.test(path)) {
    return path;
  }

  const normalizedBase = base.replace(/\/+$/, "");
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${normalizedBase}${normalizedPath}`;
}

export function getCurrentUrl(): string | null {
  if (typeof window === "undefined") {
    return null;
  }

  return window.location.href;
}

export function buildAccountCenterUrl(
  accountCenterUrl: string,
  options: {
    flow?: "manage" | "add-account" | "add";
    reason?: IdentityRecoveryReason;
    returnTo?: string | null;
  } = {}
): string {
  if (typeof window === "undefined") {
    return accountCenterUrl;
  }

  const url = new URL(accountCenterUrl, window.location.origin);

  if (options.flow) {
    url.searchParams.set("flow", options.flow === "add-account" ? "add" : options.flow);
  }

  if (options.reason) {
    url.searchParams.set("reason", options.reason);
  }

  if (options.returnTo) {
    url.searchParams.set("returnTo", options.returnTo);
  }

  return url.toString();
}
