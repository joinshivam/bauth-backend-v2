export type IdentityStatus =
  | "idle"
  | "loading"
  | "authenticated"
  | "anonymous"
  | "recovering"
  | "error";

export type IdentityRecoveryReason =
  | "session_expired"
  | "invalid_session"
  | "revoked_session"
  | "unauthorized"
  | "manual"
  | "unknown";

export type IdentityRedirectMode = "assign" | "replace" | "none";

export interface IdentityAccount {
  id: string;
  name: string;
  username?: string;
  email?: string;
  avatarUrl?: string | null;
  photo?: string | null;
  profilePhoto?: string | null;
  initials?: string;
  active?: boolean;
  metadata?: Record<string, unknown>;
}

export interface IdentityError {
  message: string;
  status?: number;
  code?: string;
  recoverable?: boolean;
  cause?: unknown;
}

export interface IdentitySessionPayload {
  accounts?: IdentityAccount[];
  activeAccount?: IdentityAccount | null;
  activeUser?: IdentityAccount | null;
  user?: IdentityAccount | null;
  activeAccountId?: string | null;
  sessions?: IdentityAccount[] | Record<string, IdentityAccount>;
  active?: string | null;
  activeSession?: string | null;
  activeSessionId?: string | null;
  activeCandidate?: IdentityAccount | null;
}

export type IdentitySessionPayloadMapper = (
  payload: IdentitySessionPayload | null
) => IdentitySessionPayload | null | undefined;

export interface IdentityActionContext {
  accountId?: string;
  snapshot: IdentitySnapshot;
}

export interface IdentitySnapshot {
  status: IdentityStatus;
  accounts: IdentityAccount[];
  activeAccount: IdentityAccount | null;
  error: IdentityError | null;
  pendingAccountId: string | null;
  hydratedAt: number | null;
}

export interface IdentityEndpoints {
  sessions: string;
  switch: string;
  logout: string;
  logoutAll: string;
}

export type IdentityFetcher = (
  input: RequestInfo | URL,
  init?: RequestInit
) => Promise<Response>;

export interface IdentityRecoveryContext {
  reason: IdentityRecoveryReason;
  recoveryUrl: string;
  returnTo: string | null;
  error?: IdentityError;
}

export interface IdentityConfig {
  apiBase: string;
  accountCenterUrl: string;
  loginUrl?: string;
  manageAccountUrl?: string;
  addAccountUrl?: string;
  endpoints?: Partial<IdentityEndpoints>;
  fetcher?: IdentityFetcher;
  credentials?: RequestCredentials;
  storageKey?: string;
  broadcastChannelName?: string;
  recoveryRedirectMode?: IdentityRedirectMode;
  redirect?: (url: string, mode: Exclude<IdentityRedirectMode, "none">) => void;
  mapSessionPayload?: IdentitySessionPayloadMapper;
  onRecovery?: (context: IdentityRecoveryContext) => void | Promise<void>;
  onSessionChange?: (snapshot: IdentitySnapshot) => void;
  onSwitchAccount?: (context: IdentityActionContext) => void | Promise<void>;
  onLogout?: (context: IdentityActionContext) => void | Promise<void>;
  onLogoutAll?: (context: IdentityActionContext) => void | Promise<void>;
}

export interface IdentityRuntime {
  getSnapshot: () => IdentitySnapshot;
  subscribe: (listener: () => void) => () => void;
  hydrate: (options?: { silent?: boolean }) => Promise<IdentitySnapshot>;
  switchAccount: (accountId: string) => Promise<IdentitySnapshot>;
  logout: () => Promise<IdentitySnapshot>;
  logoutAll: () => Promise<IdentitySnapshot>;
  addAccount: () => void;
  manageAccount: () => void;
  recoverAuth: (
    reason?: IdentityRecoveryReason,
    error?: IdentityError
  ) => Promise<IdentitySnapshot>;
  destroy: () => void;
}

export interface IdentitySyncEvent {
  type: "session-changed" | "logout" | "logout-all" | "recover";
  reason?: IdentityRecoveryReason;
  accountId?: string;
  timestamp: number;
  sourceId: string;
}
