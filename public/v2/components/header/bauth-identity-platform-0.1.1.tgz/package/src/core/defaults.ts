import type { IdentityEndpoints, IdentitySnapshot } from "./types";

export const DEFAULT_IDENTITY_ENDPOINTS: IdentityEndpoints = {
  sessions: "/api/auth/sessions",
  switch: "/api/user/switch",
  logout: "/api/user/logout",
  logoutAll: "/api/users/logout",
};

export const DEFAULT_STORAGE_KEY = "bauth.identity.snapshot";

export const DEFAULT_BROADCAST_CHANNEL = "bauth.identity";

export const INITIAL_IDENTITY_SNAPSHOT: IdentitySnapshot = {
  status: "idle",
  accounts: [],
  activeAccount: null,
  error: null,
  pendingAccountId: null,
  hydratedAt: null
};
