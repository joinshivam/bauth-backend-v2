import type { IdentityConfig, IdentityRuntime } from "./types";
import { IdentitySessionManager } from "../services/session-manager";

export function createIdentityRuntime(config: IdentityConfig): IdentityRuntime {
  return new IdentitySessionManager(config);
}
