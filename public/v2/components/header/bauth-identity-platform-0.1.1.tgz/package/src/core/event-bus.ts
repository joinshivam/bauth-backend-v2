export type IdentityListener = () => void;

export class IdentityEventBus {
  private readonly listeners = new Set<IdentityListener>();

  subscribe(listener: IdentityListener): () => void {
    this.listeners.add(listener);

    return () => {
      this.listeners.delete(listener);
    };
  }

  emit(): void {
    for (const listener of this.listeners) {
      listener();
    }
  }

  clear(): void {
    this.listeners.clear();
  }
}
