import type { IdentityAccount } from "../core/types";

export interface AccountAvatarProps {
  account: IdentityAccount | null;
  size?: "sm" | "md" | "lg";
}

export function AccountAvatar({ account, size = "md" }: AccountAvatarProps) {
  const initials = account ? getInitials(account) : "B";
  const avatarUrl = account?.avatarUrl ?? null;

  return (
    <span className={`bauth-avatar bauth-avatar--${size}`} aria-hidden="true">
      {avatarUrl ? (
        <img
          src={avatarUrl}
          alt=""
          className="bauth-avatar__image"
          crossOrigin="use-credentials"
        />
      ) : (
        <span className="bauth-avatar__initials">{initials}</span>
      )}
    </span>
  );
}

function getInitials(account: IdentityAccount): string {
  if (account.initials) {
    return account.initials.slice(0, 2).toUpperCase();
  }

  const source = account.name || account.username || account.email || "BAuth";
  const words = source.trim().split(/\s+/);

  if (words.length === 1) {
    return words[0].slice(0, 2).toUpperCase();
  }

  return `${words[0][0]}${words[1][0]}`.toUpperCase();
}
