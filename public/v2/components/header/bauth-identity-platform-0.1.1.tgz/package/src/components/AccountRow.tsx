import type { IdentityAccount } from "../core/types";
import { AccountAvatar } from "./AccountAvatar";

export interface AccountRowProps {
  account: IdentityAccount;
  active?: boolean;
  pending?: boolean;
  onSelect: (accountId: string) => void;
}

export function AccountRow({
  account,
  active = false,
  pending = false,
  onSelect
}: AccountRowProps) {
  return (
    <button
      type="button"
      className="bauth-account-row"
      onClick={() => onSelect(account.id)}
      disabled={active || pending}
      aria-current={active ? "true" : undefined}
    >
      <AccountAvatar account={account} size="sm" />
      <span className="bauth-account-row__text">
        <span className="bauth-account-row__name">{account.name}</span>
        <span className="bauth-account-row__username">
          {account.username ?? account.email}
        </span>
      </span>
      <span className="bauth-account-row__state">
        {pending ? "Switching" : active ? "Active" : "Switch"}
      </span>
    </button>
  );
}
