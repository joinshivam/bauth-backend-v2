import type { IdentityConfig } from "../core/types";
import { IdentityHeader, type IdentityHeaderProps } from "./IdentityHeader";
import { IdentityProvider } from "../providers/IdentityProvider";

export interface IdentityPlatformProps {
  config: IdentityConfig;
  header?: IdentityHeaderProps;
}

export function IdentityPlatform({ config, header }: IdentityPlatformProps) {
  return (
    <IdentityProvider config={config}>
      <IdentityHeader {...header} />
    </IdentityProvider>
  );
}
