import { useIdentity } from "../hooks/useIdentity";
import { AccountAvatar } from "./AccountAvatar";
import { AccountRow } from "./AccountRow";

export interface IdentityPopupProps {
  onClose: () => void;
}

export function IdentityPopup({ onClose }: IdentityPopupProps) {
  const identity = useIdentity();
  const { activeAccount, accounts, pendingAccountId, status } = identity;

  const visibleAccounts = accounts.length
    ? accounts
    : activeAccount
      ? [activeAccount]
      : [];

  const handleSwitchAccount = async (accountId: string) => {
    await identity.switchAccount(accountId);
    onClose();
  };

  const handleLogout = async () => {
    await identity.logout();
    onClose();
  };

  const handleLogoutAll = async () => {
    await identity.logoutAll();
    onClose();
  };

  return (
    <div className="bauth-popup__content">
      <div className="bauth-popup__identity">
        <AccountAvatar account={activeAccount} size="lg" />
        <div className="bauth-popup__person">
          <div className="bauth-popup__name">
            {activeAccount?.name ?? "Bauth account"}
          </div>
          <div className="bauth-popup__username">
            {activeAccount?.username ?? activeAccount?.email ?? "Session unavailable"}
          </div>
        </div>
      </div>

      {status === "recovering" ? (
        <div className="bauth-popup__notice" role="status">
          Recovering session
        </div>
      ) : null}

      {status === "error" ? (
        <div className="bauth-popup__notice" role="status">
          Account session needs attention
        </div>
      ) : null}

      <div className="bauth-popup__actions" aria-label="Account actions">
        <button
          type="button"
          className="bauth-action bauth-action--primary"
          onClick={identity.manageAccount}
        >
          Manage account
        </button>
        <button type="button" className="bauth-action" onClick={identity.addAccount}>
          Add account
        </button>
      </div>

      <div className="bauth-popup__section">
        <div className="bauth-popup__section-title">Switch account</div>
        <div className="bauth-account-list">
          {visibleAccounts.length ? (
            visibleAccounts.map((account) => (
              <AccountRow
                key={account.id}
                account={account}
                active={account.id === activeAccount?.id}
                pending={account.id === pendingAccountId}
                onSelect={handleSwitchAccount}
              />
            ))
          ) : (
            <div className="bauth-empty-state">No active BAuth session</div>
          )}
        </div>
      </div>

      <div className="bauth-popup__footer">
        <button type="button" className="bauth-logout" onClick={handleLogout}>
          Logout
        </button>
        <button
          type="button"
          className="bauth-logout bauth-logout--muted"
          onClick={handleLogoutAll}
        >
          Logout all
        </button>
      </div>
    </div>
  );
}
