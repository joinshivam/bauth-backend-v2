import "../styles/identity-platform.css";
import { FloatingPortal } from "../floating/FloatingPortal";
import { useFloatingPopup } from "../floating/useFloatingPopup";
import { useIdentity } from "../hooks/useIdentity";
import { classNames } from "../utils/classNames";
import { AccountAvatar } from "./AccountAvatar";
import { IdentityPopup } from "./IdentityPopup";

export interface IdentityHeaderProps {
  className?: string;
  fixed?: boolean;
  ariaLabel?: string;
}

export function IdentityHeader({
  className,
  fixed = true,
  ariaLabel = "Open BAuth account menu"
}: IdentityHeaderProps) {
  const identity = useIdentity();
  const floating = useFloatingPopup();
  const isBusy =
    identity.status === "loading" ||
    identity.status === "recovering" ||
    Boolean(identity.pendingAccountId);
  
  return (
    <div
      className={classNames(
        "bauth-identity-platform",
        "bauth-identity-header",
        fixed && "bauth-identity-header--fixed",
        className
      )}
      data-bauth-identity-layer="header"
      data-status={identity.status}
    >
      <button
        ref={floating.triggerRef}
        type="button"
        className="bauth-avatar-button"
        onClick={floating.toggle}
        aria-label={ariaLabel}
        aria-haspopup="dialog"
        aria-expanded={floating.isOpen}
        data-busy={isBusy ? "true" : "false"}
      >
        <AccountAvatar account={identity.activeAccount} />
        <span className="bauth-avatar-button__status" />
      </button>

      {floating.isOpen ? (
        <FloatingPortal>
          <div
            ref={floating.popupRef}
            className="bauth-popup"
            role="dialog"
            aria-modal="false"
            aria-label="BAuth identity menu"
            style={floating.floatingStyle}
          >
            <IdentityPopup onClose={() => floating.setOpen(false)} />
          </div>
        </FloatingPortal>
      ) : null}
    </div>
  );
}
