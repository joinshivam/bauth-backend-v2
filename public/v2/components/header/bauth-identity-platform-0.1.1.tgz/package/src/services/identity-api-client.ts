import { DEFAULT_IDENTITY_ENDPOINTS } from "../core/defaults";
import type {
  IdentityConfig,
  IdentityEndpoints,
  IdentityError,
  IdentityFetcher,
  IdentitySessionPayload
} from "../core/types";
import { joinUrl } from "../utils/url";

export class IdentityApiError extends Error implements IdentityError {
  status?: number;
  code?: string;
  recoverable?: boolean;
  cause?: unknown;

  constructor(message: string, error: Omit<IdentityError, "message"> = {}) {
    super(message);
    this.name = "IdentityApiError";
    this.status = error.status;
    this.code = error.code;
    this.recoverable = error.recoverable;
    this.cause = error.cause;
  }
}

export class IdentityApiClient {
  private readonly apiBase: string;
  private readonly endpoints: IdentityEndpoints;
  private readonly fetcher: IdentityFetcher;
  private readonly credentials: RequestCredentials;

  constructor(config: IdentityConfig) {
    const fetcher = config.fetcher ?? globalThis.fetch?.bind(globalThis);

    if (!fetcher) {
      throw new IdentityApiError("BAuth Identity requires a fetch implementation.");
    }

    this.apiBase = config.apiBase;
    this.fetcher = fetcher;
    this.credentials = config.credentials ?? "include";
    this.endpoints = {
      ...DEFAULT_IDENTITY_ENDPOINTS,
      ...config.endpoints
    };
  }

  getSessions(): Promise<IdentitySessionPayload> {
    return this.request<IdentitySessionPayload>(this.endpoints.sessions, {
      method: "GET"
    });
  }

switchAccount(accountId: string): Promise<IdentitySessionPayload> {
  return this.request<IdentitySessionPayload>(this.endpoints.switch, {
    method: "POST",
    body: JSON.stringify({ sessionId: accountId })
  });
}

  logout(): Promise<IdentitySessionPayload | null> {
    return this.request<IdentitySessionPayload | null>(this.endpoints.logout, {
      method: "POST"
    });
  }

  logoutAll(): Promise<IdentitySessionPayload | null> {
    return this.request<IdentitySessionPayload | null>(this.endpoints.logoutAll, {
      method: "POST"
    });
  }

  private async request<T>(path: string, init: RequestInit): Promise<T> {
    const response = await this.fetcher(joinUrl(this.apiBase, path), {
      ...init,
      credentials: this.credentials,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        ...init.headers
      }
    });

    if (response.status === 204) {
      return null as T;
    }

    const body = await readResponseBody(response);

    if (!response.ok) {
      throw new IdentityApiError(resolveErrorMessage(body, response), {
        status: response.status,
        code: resolveErrorCode(body),
        recoverable: isRecoverableStatus(response.status),
        cause: body
      });
    }

    return body as T;
  }
}

async function readResponseBody(response: Response): Promise<unknown> {
  const contentType = response.headers.get("content-type") ?? "";

  if (contentType.includes("application/json")) {
    try {
      return await response.json();
    } catch {
      return null;
    }
  }

  const text = await response.text();
  return text ? { message: text } : null;
}

function resolveErrorMessage(body: unknown, response: Response): string {
  if (typeof body === "object" && body && "message" in body) {
    return String((body as { message: unknown }).message);
  }

  return `BAuth Identity request failed with ${response.status}.`;
}

function resolveErrorCode(body: unknown): string | undefined {
  if (typeof body === "object" && body && "code" in body) {
    return String((body as { code: unknown }).code);
  }

  return undefined;
}

export function isRecoverableStatus(status?: number): boolean {
  return status === 401 || status === 403 || status === 419 || status === 440;
}
