import { INITIAL_IDENTITY_SNAPSHOT } from "../core/defaults";
import { IdentityEventBus } from "../core/event-bus";
import type {
  IdentityAccount,
  IdentityConfig,
  IdentityError,
  IdentityRecoveryReason,
  IdentityRuntime,
  IdentitySessionPayload,
  IdentitySnapshot
} from "../core/types";
import {
  IdentityApiClient,
  IdentityApiError,
  isRecoverableStatus
} from "./identity-api-client";
import { AuthRecoveryController } from "./auth-recovery";
import { IdentityStorageSync } from "./storage-sync";

export class IdentitySessionManager implements IdentityRuntime {
  private readonly bus = new IdentityEventBus();
  private readonly api: IdentityApiClient;
  private readonly recovery: AuthRecoveryController;
  private readonly sync: IdentityStorageSync;
  private snapshot: IdentitySnapshot = { ...INITIAL_IDENTITY_SNAPSHOT };
  private hydrationPromise: Promise<IdentitySnapshot> | null = null;
  private unsubscribeSync: (() => void) | null = null;

  constructor(private readonly config: IdentityConfig) {
    this.api = new IdentityApiClient(config);
    this.recovery = new AuthRecoveryController(config);
    this.sync = new IdentityStorageSync(config);
    this.unsubscribeSync = this.sync.subscribe((event) => {
      if (event.type === "session-changed" || event.type === "logout") {
        void this.hydrate({ silent: true });
      }

      if (event.type === "logout-all" || event.type === "recover") {
        this.setSnapshot({
          status: "anonymous",
          accounts: [],
          activeAccount: null,
          error: null,
          pendingAccountId: null,
          hydratedAt: Date.now()
        });
      }
    });
  }

  getSnapshot = (): IdentitySnapshot => this.snapshot;

  subscribe = (listener: () => void): (() => void) => this.bus.subscribe(listener);

  hydrate = async (
    options: { silent?: boolean } = {}
  ): Promise<IdentitySnapshot> => {
    if (this.hydrationPromise) {
      return this.hydrationPromise;
    }

    if (!options.silent) {
      this.setSnapshot({
        ...this.snapshot,
        status: "loading",
        error: null
      });
    }

    this.hydrationPromise = this.api
      .getSessions()
      .then((payload) => {
        const normalized = this.normalizeSessionPayload(payload);
        const next: IdentitySnapshot = {
          status: normalized.activeAccount ? "authenticated" : "anonymous",
          accounts: normalized.accounts,
          activeAccount: normalized.activeAccount,
          error: null,
          pendingAccountId: null,
          hydratedAt: Date.now()
        };

        this.setSnapshot(next);
        return next;
      })
      .catch((error) => this.handleRequestFailure(error, "session_expired"))
      .finally(() => {
        this.hydrationPromise = null;
      });

    return this.hydrationPromise;
  };

  switchAccount = async (accountId: string): Promise<IdentitySnapshot> => {
    if (!accountId || accountId === this.snapshot.activeAccount?.id) {
      return this.snapshot;
    }

    this.setSnapshot({
      ...this.snapshot,
      pendingAccountId: accountId,
      error: null
    });

    try {
      await this.api.switchAccount(accountId);
      const next = await this.hydrate({ silent: true });
      this.sync.publish({ type: "session-changed", accountId });
      await this.config.onSwitchAccount?.({ accountId, snapshot: next });
      return next;
    } catch (error) {
      return this.handleRequestFailure(error, "invalid_session");
    }
  };

  logout = async (): Promise<IdentitySnapshot> => {
    try {
      const payload = await this.api.logout();
      this.sync.publish({ type: "logout" });

      const next = hasSessionPayloadData(payload)
        ? this.applyPayload(payload)
        : this.applyAnonymousSnapshot();

      await this.config.onLogout?.({ snapshot: next });
      return next;
    } catch (error) {
      return this.handleRequestFailure(error, "invalid_session");
    }
  };

  logoutAll = async (): Promise<IdentitySnapshot> => {
    try {
      await this.api.logoutAll();
      this.sync.publish({ type: "logout-all" });

      const next: IdentitySnapshot = {
        status: "anonymous",
        accounts: [],
        activeAccount: null,
        error: null,
        pendingAccountId: null,
        hydratedAt: Date.now()
      };

      this.setSnapshot(next);
      await this.config.onLogoutAll?.({ snapshot: next });
      return next;
    } catch (error) {
      return this.handleRequestFailure(error, "invalid_session");
    }
  };

  addAccount = (): void => {
    this.recovery.addAccount();
  };

  manageAccount = (): void => {
    this.recovery.manageAccount();
  };

  recoverAuth = async (
    reason: IdentityRecoveryReason = "manual",
    error?: IdentityError
  ): Promise<IdentitySnapshot> => {
    const identityError = error ?? {
      message: "Authentication recovery was requested.",
      recoverable: true
    };

    this.sync.publish({ type: "recover", reason });
    this.setSnapshot({
      status: "recovering",
      accounts: [],
      activeAccount: null,
      error: identityError,
      pendingAccountId: null,
      hydratedAt: Date.now()
    });

    await this.recovery.recover(reason, identityError);

    const next: IdentitySnapshot = {
      status: "anonymous",
      accounts: [],
      activeAccount: null,
      error: null,
      pendingAccountId: null,
      hydratedAt: Date.now()
    };

    this.setSnapshot(next);
    return next;
  };

  destroy = (): void => {
    this.unsubscribeSync?.();
    this.unsubscribeSync = null;
    this.sync.destroy();
    this.bus.clear();
  };

  private applyPayload(payload: IdentitySessionPayload): IdentitySnapshot {
    const normalized = this.normalizeSessionPayload(payload);
    const next: IdentitySnapshot = {
      status: normalized.activeAccount ? "authenticated" : "anonymous",
      accounts: normalized.accounts,
      activeAccount: normalized.activeAccount,
      error: null,
      pendingAccountId: null,
      hydratedAt: Date.now()
    };

    this.setSnapshot(next);
    return next;
  }

  private normalizeSessionPayload(payload: IdentitySessionPayload | null): {
    accounts: IdentityAccount[];
    activeAccount: IdentityAccount | null;
  } {
    const mapped = this.config.mapSessionPayload?.(payload) ?? payload;
    return normalizeSessionPayload(mapped);
  }

  private applyAnonymousSnapshot(): IdentitySnapshot {
    const next: IdentitySnapshot = {
      status: "anonymous",
      accounts: [],
      activeAccount: null,
      error: null,
      pendingAccountId: null,
      hydratedAt: Date.now()
    };

    this.setSnapshot(next);
    return next;
  }

  private async handleRequestFailure(
    error: unknown,
    fallbackReason: IdentityRecoveryReason
  ): Promise<IdentitySnapshot> {
    const identityError = toIdentityError(error);

    if (identityError.recoverable || isRecoverableStatus(identityError.status)) {
      return this.recoverAuth(resolveRecoveryReason(identityError, fallbackReason), identityError);
    }

    const next: IdentitySnapshot = {
      ...this.snapshot,
      status: "error",
      error: identityError,
      pendingAccountId: null
    };

    this.setSnapshot(next);
    return next;
  }

  private setSnapshot(next: IdentitySnapshot): void {
    this.snapshot = next;
    this.config.onSessionChange?.(next);
    this.bus.emit();
  }
}

function normalizeSessionPayload(payload: IdentitySessionPayload | null): {
  accounts: IdentityAccount[];
  activeAccount: IdentityAccount | null;
} {
  if (!payload) {
    return { accounts: [], activeAccount: null };
  }
   
  const rawSessions = payload.accounts ?? payload.sessions ?? [];

  const rawAccounts = Array.isArray(rawSessions)
    ? rawSessions.map((account) => normalizeAccount(account))
    : Object.entries(rawSessions).map(([sessionId, session]) =>
        normalizeAccount(session, sessionId)
      );
  const accountsFromPayload = rawAccounts.filter(isIdentityAccount);
  const activeCandidate =
    normalizeAccount(payload.activeAccount ?? payload.activeUser ?? payload.user ?? undefined) ??
    accountsFromPayload.find((account) => account.active) ??
    accountsFromPayload[0] ??
    null;

  const activeAccountId =
    payload.activeAccountId ??
    payload.activeSessionId ??
    payload.activeSession ??
    payload.active ??
    activeCandidate?.id ??
    accountsFromPayload.find((account) => account.active)?.id ??
    accountsFromPayload[0]?.id;

  const accounts = accountsFromPayload.map((account) => ({
    ...account,
    active: account.id === activeAccountId
  }));

  const activeAccount =
    accounts.find((account) => account.id === activeAccountId) ??
    (activeCandidate ? { ...activeCandidate, active: true } : null);

  if (
    activeAccount &&
    !accounts.some((account) => account.id === activeAccount.id)
  ) {
    return {
      accounts: [{ ...activeAccount, active: true }, ...accounts],
      activeAccount
    };
  }

  return { accounts, activeAccount };
}

function normalizeAccount(
  value: IdentityAccount | unknown,
  fallbackId?: string
): IdentityAccount | null {
  if (!value || typeof value !== "object") {
    return null;
  }

  const account = value as Partial<IdentityAccount> & {
    sub?: string | number;
    sessionId?: string | number;
    db_session_id?: string | number;
  };
  const id = String(
    fallbackId ?? account.id ?? account.sessionId ?? account.sub ?? account.db_session_id ?? ""
  );

  if (!id) {
    return null;
  }

  const name =
    account.name ??
    account.username ??
    account.email ??
    "BAuth account";

  return {
    ...(account as IdentityAccount),
    id,
    name: String(name),
    username: account.username ? String(account.username) : undefined,
    email: account.email ? String(account.email) : undefined
  };
}

function isIdentityAccount(account: IdentityAccount | null): account is IdentityAccount {
  return Boolean(account);
}

function hasSessionPayloadData(
  payload: IdentitySessionPayload | null | unknown
): payload is IdentitySessionPayload {
  if (!payload || typeof payload !== "object") {
    return false;
  }

  return (
    "accounts" in payload ||
    "sessions" in payload ||
    "activeAccount" in payload ||
    "activeUser" in payload ||
    "user" in payload ||
    "activeAccountId" in payload ||
    "activeSessionId" in payload ||
    "activeSession" in payload ||
    "active" in payload
  );
}

function toIdentityError(error: unknown): IdentityError {
  if (error instanceof IdentityApiError) {
    return {
      message: error.message,
      status: error.status,
      code: error.code,
      recoverable: error.recoverable,
      cause: error.cause
    };
  }

  if (error instanceof Error) {
    return {
      message: error.message,
      cause: error
    };
  }

  return {
    message: "BAuth Identity encountered an unknown error.",
    cause: error
  };
}

function resolveRecoveryReason(
  error: IdentityError,
  fallbackReason: IdentityRecoveryReason
): IdentityRecoveryReason {
  if (error.code === "SESSION_REVOKED") {
    return "revoked_session";
  }

  if (error.status === 401) {
    return "unauthorized";
  }

  return fallbackReason;
}
