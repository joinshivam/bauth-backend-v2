import type {
  IdentityConfig,
  IdentityError,
  IdentityRecoveryReason
} from "../core/types";
import { buildAccountCenterUrl, getCurrentUrl } from "../utils/url";

export class AuthRecoveryController {
  constructor(private readonly config: IdentityConfig) {}

  async recover(
    reason: IdentityRecoveryReason,
    error?: IdentityError
  ): Promise<void> {
    const returnTo = getCurrentUrl();
    const recoveryUrl = buildAccountCenterUrl(this.config.accountCenterUrl, {
      reason,
      returnTo
    });

    await this.config.onRecovery?.({
      reason,
      recoveryUrl,
      returnTo,
      error
    });

    const mode = this.config.recoveryRedirectMode ?? "replace";

    if (mode !== "none") {
      this.redirectTo(recoveryUrl, mode);
    }
  }

  manageAccount(): void {
    const url =
      this.config.manageAccountUrl ??
      buildAccountCenterUrl(this.config.accountCenterUrl, {
        flow: "manage",
        returnTo: getCurrentUrl()
      });

    this.redirectTo(url, "assign");
  }

  addAccount(): void {
    const url =
      this.config.addAccountUrl ??
      buildAccountCenterUrl(this.config.accountCenterUrl, {
        flow: "add-account",
        returnTo: getCurrentUrl()
      });

    this.redirectTo(url, "assign");
  }

  redirectTo(url: string, mode: "assign" | "replace"): void {
    if (this.config.redirect) {
      this.config.redirect(url, mode);
      return;
    }

    if (typeof window === "undefined") {
      return;
    }

    if (mode === "replace") {
      window.location.replace(url);
      return;
    }

    window.location.assign(url);
  }
}
