import {
  DEFAULT_BROADCAST_CHANNEL,
  DEFAULT_STORAGE_KEY
} from "../core/defaults";
import type { IdentityConfig, IdentitySyncEvent } from "../core/types";

export class IdentityStorageSync {
  private readonly channelName: string;
  private readonly storageKey: string;
  private readonly sourceId = createSourceId();
  private channel: BroadcastChannel | null = null;
  private unsubscribeStorage: (() => void) | null = null;

  constructor(config: IdentityConfig) {
    this.channelName = config.broadcastChannelName ?? DEFAULT_BROADCAST_CHANNEL;
    this.storageKey = config.storageKey ?? DEFAULT_STORAGE_KEY;
  }

  getSourceId(): string {
    return this.sourceId;
  }

  subscribe(handler: (event: IdentitySyncEvent) => void): () => void {
    if (typeof window === "undefined") {
      return () => undefined;
    }

    if ("BroadcastChannel" in window) {
      this.channel = new BroadcastChannel(this.channelName);
      this.channel.onmessage = (event: MessageEvent<IdentitySyncEvent>) => {
        if (event.data?.sourceId !== this.sourceId) {
          handler(event.data);
        }
      };
    }

    const onStorage = (event: StorageEvent) => {
      if (event.key !== this.storageKey || !event.newValue) {
        return;
      }

      try {
        const parsed = JSON.parse(event.newValue) as IdentitySyncEvent;

        if (parsed.sourceId !== this.sourceId) {
          handler(parsed);
        }
      } catch {
        // Ignore malformed sync events from older runtimes.
      }
    };

    window.addEventListener("storage", onStorage);
    this.unsubscribeStorage = () => {
      window.removeEventListener("storage", onStorage);
    };

    return () => this.destroy();
  }

  publish(event: Omit<IdentitySyncEvent, "timestamp" | "sourceId">): void {
    if (typeof window === "undefined") {
      return;
    }

    const payload: IdentitySyncEvent = {
      ...event,
      timestamp: Date.now(),
      sourceId: this.sourceId
    };

    this.channel?.postMessage(payload);

    try {
      window.localStorage.setItem(this.storageKey, JSON.stringify(payload));
      window.localStorage.removeItem(this.storageKey);
    } catch {
      // Storage can be disabled in embedded contexts; BroadcastChannel still works.
    }
  }

  destroy(): void {
    this.channel?.close();
    this.channel = null;
    this.unsubscribeStorage?.();
    this.unsubscribeStorage = null;
  }
}

function createSourceId(): string {
  if (globalThis.crypto?.randomUUID) {
    return globalThis.crypto.randomUUID();
  }

  return `bauth-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
