import {
  type ReactNode,
  useEffect,
  useMemo,
  useRef,
  useSyncExternalStore
} from "react";
import { createIdentityRuntime } from "../core/runtime";
import type { IdentityConfig, IdentityRuntime } from "../core/types";
import { IdentityContext, type IdentityContextValue } from "./IdentityContext";

export interface IdentityProviderProps {
  children: ReactNode;
  config?: IdentityConfig;
  runtime?: IdentityRuntime;
  autoHydrate?: boolean;
}

export function IdentityProvider({
  children,
  config,
  runtime,
  autoHydrate = true
}: IdentityProviderProps) {
  const runtimeRef = useRef<IdentityRuntime | null>(null);
  const ownsRuntimeRef = useRef(false);

  if (!runtimeRef.current) {
    if (runtime) {
      runtimeRef.current = runtime;
    } else if (config) {
      runtimeRef.current = createIdentityRuntime(config);
      ownsRuntimeRef.current = true;
    } else {
      throw new Error("IdentityProvider requires either config or runtime.");
    }
  }

  const identityRuntime = runtimeRef.current;
  const snapshot = useSyncExternalStore(
    identityRuntime.subscribe,
    identityRuntime.getSnapshot,
    identityRuntime.getSnapshot
  );

  useEffect(() => {
    if (autoHydrate) {
      void identityRuntime.hydrate();
    }

    return () => {
      if (ownsRuntimeRef.current) {
        identityRuntime.destroy();
      }
    };
  }, [autoHydrate, identityRuntime]);

  const value = useMemo<IdentityContextValue>(
    () => ({
      ...snapshot,
      runtime: identityRuntime,
      hydrate: identityRuntime.hydrate,
      switchAccount: identityRuntime.switchAccount,
      logout: identityRuntime.logout,
      logoutAll: identityRuntime.logoutAll,
      addAccount: identityRuntime.addAccount,
      manageAccount: identityRuntime.manageAccount,
      recoverAuth: identityRuntime.recoverAuth
    }),
    [identityRuntime, snapshot]
  );

  return <IdentityContext.Provider value={value}>{children}</IdentityContext.Provider>;
}
