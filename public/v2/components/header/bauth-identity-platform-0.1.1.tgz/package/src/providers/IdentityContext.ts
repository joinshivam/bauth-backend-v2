import { createContext } from "react";
import type { IdentityRuntime, IdentitySnapshot } from "../core/types";

export interface IdentityContextValue extends IdentitySnapshot {
  runtime: IdentityRuntime;
  hydrate: IdentityRuntime["hydrate"];
  switchAccount: IdentityRuntime["switchAccount"];
  logout: IdentityRuntime["logout"];
  logoutAll: IdentityRuntime["logoutAll"];
  addAccount: IdentityRuntime["addAccount"];
  manageAccount: IdentityRuntime["manageAccount"];
  recoverAuth: IdentityRuntime["recoverAuth"];
}

export const IdentityContext = createContext<IdentityContextValue | null>(null);
