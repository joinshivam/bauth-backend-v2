import "./styles/identity-platform.css";

export { createIdentityRuntime } from "./core/runtime";
export type {
  IdentityAccount,
  IdentityConfig,
  IdentityEndpoints,
  IdentityError,
  IdentityRecoveryContext,
  IdentityRecoveryReason,
  IdentityRuntime,
  IdentitySessionPayload,
  IdentitySnapshot,
  IdentityStatus
} from "./core/types";

export { IdentityProvider } from "./providers/IdentityProvider";
export type { IdentityProviderProps } from "./providers/IdentityProvider";
export type { IdentityContextValue } from "./providers/IdentityContext";
export { useIdentity } from "./hooks/useIdentity";
export { IdentityHeader } from "./components/IdentityHeader";
export type { IdentityHeaderProps } from "./components/IdentityHeader";
export { IdentityPlatform } from "./components/IdentityPlatform";
export type { IdentityPlatformProps } from "./components/IdentityPlatform";
export {
  installBAuthGlobal,
  mountIdentityPlatform
} from "./adapters/browser";
export type {
  BAuthMountOptions,
  MountedIdentityPlatform
} from "./adapters/browser";
export { AuthRecoveryController } from "./recovery";
export { IdentitySessionManager, IdentityStorageSync } from "./session";
