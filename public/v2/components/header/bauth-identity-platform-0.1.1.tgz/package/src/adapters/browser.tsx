import { createElement } from "react";
import { createRoot, type Root } from "react-dom/client";
import type { IdentityConfig } from "../core/types";
import {
  IdentityPlatform,
  type IdentityPlatformProps
} from "../components/IdentityPlatform";

export interface BAuthMountOptions extends IdentityPlatformProps {
  target?: Element | string;
  isolation?: "portal" | "shadow-ready";
}

export interface MountedIdentityPlatform {
  root: Root;
  container: Element;
  unmount: () => void;
}

export function mountIdentityPlatform(
  options: BAuthMountOptions
): MountedIdentityPlatform {
  const container = resolveContainer(options.target);
  const root = createRoot(container);

  root.render(
    createElement(IdentityPlatform, {
      config: options.config,
      header: options.header
    })
  );

  return {
    root,
    container,
    unmount: () => root.unmount()
  };
}

export function installBAuthGlobal(defaultConfig?: IdentityConfig): void {
  if (typeof window === "undefined") {
    return;
  }

  window.BAuth = {
    ...window.BAuth,
    mount: (options?: Partial<BAuthMountOptions>) => {
      const config = options?.config ?? defaultConfig;

      if (!config) {
        throw new Error("window.BAuth.mount requires an identity config.");
      }

      return mountIdentityPlatform({
        ...options,
        config
      });
    }
  };
}

function resolveContainer(target?: Element | string): Element {
  if (typeof document === "undefined") {
    throw new Error("BAuth Identity can only mount in a browser document.");
  }

  if (isElement(target)) {
    return target;
  }

  if (typeof target === "string") {
    const selected = document.querySelector(target);

    if (!selected) {
      throw new Error(`BAuth Identity target was not found: ${target}`);
    }

    return selected;
  }

  const container = document.createElement("div");
  container.setAttribute("data-bauth-identity-layer", "mount");
  document.body.appendChild(container);
  return container;
}

function isElement(value: unknown): value is Element {
  return (
    typeof value === "object" &&
    value !== null &&
    "nodeType" in value &&
    (value as { nodeType?: number }).nodeType === 1
  );
}

declare global {
  interface Window {
    BAuth?: {
      mount: (options?: Partial<BAuthMountOptions>) => MountedIdentityPlatform;
    };
  }
}
