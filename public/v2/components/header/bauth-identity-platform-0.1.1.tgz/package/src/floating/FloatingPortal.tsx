import { type ReactNode, useEffect, useState } from "react";
import { createPortal } from "react-dom";

export interface FloatingPortalProps {
  children: ReactNode;
  containerId?: string;
}

export function FloatingPortal({
  children,
  containerId = "bauth-identity-portal-root"
}: FloatingPortalProps) {
  const [container, setContainer] = useState<HTMLElement | null>(null);

  useEffect(() => {
    let portalRoot = document.getElementById(containerId);

    if (!portalRoot) {
      portalRoot = document.createElement("div");
      portalRoot.id = containerId;
      portalRoot.className = "bauth-identity-portal";
      portalRoot.setAttribute("data-bauth-identity-layer", "portal");
      document.body.appendChild(portalRoot);
    }

    setContainer(portalRoot);
  }, [containerId]);

  if (!container) {
    return null;
  }

  return createPortal(children, container);
}
