# BAuth Identity Platform

BAuth Identity Platform is an app-independent identity shell. The host app mounts it; the platform owns session hydration, account switching, logout, auth recovery, cross-tab sync, and the floating account popup.

It is intentionally not a shared dashboard header. It has no app routes, no React Router, no sidebar, no notifications, no settings grid, and no page state.

## Architecture

```text
identity-platform/
  src/
    core/          platform contracts, defaults, runtime factory
    services/      backend API client, session manager, auth recovery, sync
    session/       session runtime exports
    recovery/      recovery controller exports
    providers/     React provider boundary
    hooks/         useIdentity
    components/    IdentityHeader, popup, account rows, avatar
    ui/            UI exports for adapter packages
    floating/      portal rendering, outside click, ESC close, positioning
    adapters/      React, browser global, headless runtime exports
    styles/        isolated BAuth CSS layer
    utils/         small framework-neutral helpers
  examples/        React, Next.js, plain JS, microfrontend usage
```

## React usage

```tsx
import { IdentityHeader, IdentityProvider } from "@bauth/identity-platform";

const config = {
  apiBase: "https://api.bauth.com",
  accountCenterUrl: "https://accounts.bauth.com",
  loginUrl: "https://accounts.bauth.com/login"
};

export function App() {
  return (
    <IdentityProvider config={config}>
      <IdentityHeader />
    </IdentityProvider>
  );
}
```

## Browser global usage

```ts
import { installBAuthGlobal } from "@bauth/identity-platform";

installBAuthGlobal({
  apiBase: "https://api.bauth.com",
  accountCenterUrl: "https://accounts.bauth.com"
});

window.BAuth?.mount();
```

## Backend contract

The backend is the source of truth.

```text
GET  /auth/sessions
POST /auth/switch      { sessionId }
POST /auth/logout
POST /auth/logout-all
```

The session response can return:

```ts
{
  accounts: [{ id, name, username, email, avatarUrl }],
  activeAccountId: "acct_123"
}
```

or:

```ts
{
  activeAccount: { id, name, username, email, avatarUrl },
  accounts: []
}
```

## Recovery behavior

Recoverable API failures, including `401`, `403`, `419`, and `440`, are handled inside the platform:

- local identity state is cleared
- tabs are notified through `BroadcastChannel` and `storage`
- the runtime enters `recovering`
- the user is redirected to `accountCenterUrl`
- `reason` and `returnTo` query parameters are added

Apps do not catch identity failures or mutate identity state.

## Isolation strategy

The React header renders a compact avatar button. The popup renders through a React Portal into a dedicated `bauth-identity-portal-root` with a very high z-index. Styles use a BAuth-prefixed reset layer so host CSS does not leak into the popup.

The UI is Tailwind-inspired, but shipped as an isolated platform stylesheet. Host apps do not need Tailwind, and host Tailwind resets cannot restyle the identity popup.

The adapter API already includes an `isolation` option reserved for shadow-root mounting. That lets the platform move from portal isolation to shadow DOM isolation without changing host apps.

## Future adapter direction

The core runtime has no React imports. React is only one adapter.

- React and Next.js use `IdentityProvider`, `IdentityHeader`, and `useIdentity`
- plain JS can use `window.BAuth.mount()`
- microfrontends can share `createIdentityRuntime(config)`
- Vue/Svelte/Web Components can bind to the same runtime snapshot and actions

The invariant stays the same: apps host the identity layer, but BAuth owns identity behavior.
